@echo off
setlocal EnableExtensions DisableDelayedExpansion
Title Prime Build - Avvio strumenti v4
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
for %%F in (PrimeBuild-Common.ps1 PrimeBuild-Diagnostica.ps1 PrimeBuild-USB.ps1 LEGGIMI.txt) do if not exist "%~dp0%%F" (
  echo [ERRORE] Manca %%F. Estrai tutto lo ZIP in una cartella nuova.
  pause
  exit /b 1
)
if not exist "%PS%" (
  echo [ERRORE] Windows PowerShell non disponibile su questa macchina.
  pause
  exit /b 1
)

goto DIAGNOSTICA

:DIAGNOSTICA
cls
echo ===== DIAGNOSTICA IN SOLA LETTURA =====
echo 1. MMCSS
echo 2. BCD - richiede amministratore
echo 3. Rete e policy QoS
echo 4. Inventario USB
echo 0. Esci
choice /C 12340 /N /M "Scelta: "
if errorlevel 255 goto INPUT_ERROR
set "PICK=%errorlevel%"
if "%PICK%"=="5" exit /b 0
if "%PICK%"=="0" exit /b 0
set "PB_SCRIPT=PrimeBuild-Diagnostica.ps1"
set "PB_RETURN=DIAGNOSTICA"
if "%PICK%"=="1" set "PB_ARGS=-Section MMCSS"
if "%PICK%"=="2" set "PB_ARGS=-Section BCD"
if "%PICK%"=="3" set "PB_ARGS=-Section Network"
if "%PICK%"=="4" set "PB_ARGS=-Section USB"
if "%PICK%"=="2" echo Per BCD: se mancano i privilegi, chiudi e riapri questo BAT con Esegui come amministratore.
goto RUN

:RUN
:: Bypass vale solo per questo processo; non modifica policy persistenti o GPO.
"%PS%" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0%PB_SCRIPT%" %PB_ARGS%
set "RC=%errorlevel%"
if not "%RC%"=="0" (
  echo.
  echo [ATTENZIONE] Operazione non completata, codice %RC%. Leggi l'errore sopra.
  echo Se una policy aziendale o la sicurezza blocca l'avvio, fermati e chiedi supporto.
)
echo.
pause
goto %PB_RETURN%

:INPUT_ERROR
echo [ERRORE] Impossibile leggere la scelta. Nessuna nuova operazione avviata.
exit /b 1
