# PrimeBuild-Diagnostica-v4

PRIME BUILD - PrimeBuild-Diagnostica-v4
Windows 11 25H2 e successive

Estrai tutto questo ZIP in una cartella nuova e apri Avvia-PrimeBuild.bat con doppio clic.
Non aprire i PS1: sono componenti interni. Non mescolare versioni o cartelle.

Solo diagnostica Windows: MMCSS, BCD, rete/QoS e inventario USB.
Tutte le operazioni sono in sola lettura; non misurano latenza.
Per BCD: tasto destro sul BAT > Esegui come amministratore.
Il report puo essere parziale in caso di errore. Prima di condividerlo rimuovi dati personali.
Non include installer, modifiche mouse, avvio audio o ripristino dei vecchi preset.

I BAT limitano ExecutionPolicy Bypass al processo avviato, senza modifiche permanenti.
Le GPO hanno precedenza; antivirus/SmartScreen non vengono disabilitati.
Verifica la provenienza; se una protezione blocca l avvio, fermati e chiedi supporto.
Questi script non ripristinano i vecchi pack e non promettono guadagni di latenza.
Serve ancora una prova funzionale su PC di test prima della distribuzione stabile.
Supporto: https://discord.gg/ERUwSxE79q
Guide: https://primebuild.website/guides/
