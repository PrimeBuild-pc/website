# PrimeBuild-Input-v4

PRIME BUILD - PrimeBuild-Input-v4
Windows 11 25H2 e successive

Estrai tutto questo ZIP in una cartella nuova e apri Avvia-PrimeBuild.bat con doppio clic.
Non aprire i PS1: sono componenti interni. Non mescolare versioni o cartelle.

Solo input: stato mouse, disattivazione accelerazione, ripristino e inventario USB.
Mouse opera sul proprio utente: non usare un altro account.
Backup: LOCALAPPDATA\PrimeBuild\Backups\mouse-parameters.json. Non cancellarlo.
Non crea Raw Input, non modifica DPI/FSO/MSI e non annulla il vecchio MouseCurveFlat.
USB e sola lettura: non classifica le porte per latenza. Rimuovi dati personali prima di condividere.
Nessun HIDUSBF incluso o installato: il filtro e il suo recupero rimangono procedure manuali.

I BAT limitano ExecutionPolicy Bypass al processo avviato, senza modifiche permanenti.
Le GPO hanno precedenza; antivirus/SmartScreen non vengono disabilitati.
Verifica la provenienza; se una protezione blocca l avvio, fermati e chiedi supporto.
Questi script non ripristinano i vecchi pack e non promettono guadagni di latenza.
Serve ancora una prova funzionale su PC di test prima della distribuzione stabile.
Supporto: https://discord.gg/ERUwSxE79q
Guide: https://primebuild.website/guides/
