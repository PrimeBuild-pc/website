[CmdletBinding()]
param()
. "$PSScriptRoot\PrimeBuild-Common.ps1"

function Get-PrimeBuildUpdateTargets {
    param($Inventory)
    $excluded = @('EpicGames.EpicGamesLauncher', 'Blizzard.BattleNet', 'REALiX.HWiNFO')
    foreach ($source in $Inventory.Sources) {
        $name = $source.SourceDetails.Name
        if ($name -notin @('winget', 'msstore')) { continue }
        foreach ($package in $source.Packages) {
            $id = $package.PackageIdentifier
            if ($id -notmatch '\A[A-Za-z0-9][A-Za-z0-9._-]*\z') { throw 'ID non valido nel report Winget.' }
            if ($id -notin $excluded) {
                [pscustomobject]@{ Source = $name; Id = $id }
            }
        }
    }
}

$inventoryFile = Join-Path $env:TEMP ('PrimeBuild-Inventory-' + [guid]::NewGuid() + '.json')
try {
    Assert-PrimeBuildWindows
    if (-not (Get-Command winget.exe -ErrorAction SilentlyContinue)) { throw 'Winget assente: aggiornare App Installer.' }
    & winget.exe export --output $inventoryFile --accept-source-agreements --disable-interactivity
    if ($LASTEXITCODE -ne 0) { throw 'Inventario Winget fallito: aggiornamento annullato.' }
    $targets = @(Get-PrimeBuildUpdateTargets (Get-Content -LiteralPath $inventoryFile -Raw | ConvertFrom-Json))
    Write-Host 'App riconosciute nelle sorgenti winget/msstore. Esclusi Epic, Battle.net e HWiNFO.'
    Write-Host 'App non esportate o di altre sorgenti: aggiornare manualmente. Nessun pin viene cambiato.'
    $targets | Format-Table -AutoSize
    if ($targets.Count -eq 0) { Write-Host 'Nessuna app da elaborare.'; exit 0 }
    if ((Read-Host 'Scrivi AGGIORNA per procedere') -cne 'AGGIORNA') { Write-Host 'Annullato.'; exit 0 }
    $failed = @()
    foreach ($target in $targets) {
        Write-Host ('Aggiornamento: ' + $target.Id)
        & winget.exe upgrade --id $target.Id --exact --source $target.Source --silent --accept-package-agreements --accept-source-agreements --disable-interactivity
        $code = $LASTEXITCODE
        if (-not (Test-PrimeBuildWingetSuccess $code)) {
            $failed += $target.Id
            Write-Warning ('Non riuscito: ' + $target.Id + ' - codice ' + (Get-PrimeBuildExitHex $code))
        }
    }
    if ($failed.Count -gt 0) { throw ('Controllare queste app: ' + ($failed -join ', ')) }
    Write-Host 'Operazioni completate. Alcune app possono richiedere riavvio o updater manuale.'
    exit 0
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
} finally {
    if (Test-Path -LiteralPath $inventoryFile) { Remove-Item -LiteralPath $inventoryFile -Force }
}
