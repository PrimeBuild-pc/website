[CmdletBinding()]
param(
    [ValidateSet('Status','Install','Remove')][string]$Action = 'Status',
    [string]$ExePath
)
. "$PSScriptRoot\PrimeBuild-Common.ps1"

function Test-PrimeBuildAudioTask {
    param($Task, [string]$User)
    return $Task.Description -ceq 'Prime Build v3.0 - LowAudioLatency user startup' -and
        $Task.Principal.UserId -in @($User, [Security.Principal.WindowsIdentity]::GetCurrent().Name) -and
        @($Task.Actions).Count -eq 1 -and
        [IO.Path]::GetFileName($Task.Actions[0].Execute) -ieq 'low_audio_latency.exe'
}

function Get-PrimeBuildAudioTasks {
    param($Tasks)
    $Tasks | Where-Object {
        @($_.Actions | Where-Object {
            $executeProperty = $_.PSObject.Properties['Execute']
            $executeProperty -and [IO.Path]::GetFileName([string]$executeProperty.Value) -ieq 'low_audio_latency.exe'
        }).Count -gt 0
    }
}

try {
    Assert-PrimeBuildWindows
    $user = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $name = 'PrimeBuild-LowAudioLatency-' + $user
    $tasks = @(Get-ScheduledTask)
    $task = $tasks | Where-Object { $_.TaskPath -eq '\' -and $_.TaskName -ceq $name }
    Write-Host 'Solo avvio all accesso del proprio utente, livello Limited. Non viene usato SYSTEM.'
    Write-Host 'Default endpoint del tool; nessun argomento personalizzato. Prima verifica manualmente audio e stabilita.'
    if ($Action -eq 'Status') {
        if ($task) { $task | Format-List TaskName, State, Description, Actions, Principal }
        else { Write-Host 'Attivita non presente.' }
        exit 0
    }
    if ($Action -eq 'Install') {
        if ($task) { throw 'Attivita gia presente: non sovrascrivo. Controlla Status e usa Remove se e quella creata dal tool.' }
        $otherAudioTasks = @(Get-PrimeBuildAudioTasks $tasks)
        if ($otherAudioTasks.Count -gt 0) {
            throw ('Avvio audio gia presente: ' + (($otherAudioTasks.TaskName) -join ', ') + '. Verificalo manualmente: non lo rimuovo e non creo duplicati.')
        }
        if (-not $ExePath) {
            Add-Type -AssemblyName System.Windows.Forms
            $dialog = New-Object System.Windows.Forms.OpenFileDialog
            try {
                $dialog.Title = 'Seleziona low_audio_latency.exe gia scaricato e provato'
                $dialog.Filter = 'LowAudioLatency (low_audio_latency.exe)|low_audio_latency.exe'
                $dialog.CheckFileExists = $true
                if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
                    Write-Host 'Selezione annullata. Nessuna attivita creata.'
                    exit 0
                }
                $ExePath = $dialog.FileName
            } finally { $dialog.Dispose() }
        }
        if (-not (Test-Path -LiteralPath $ExePath -PathType Leaf)) { throw 'Indica un ExePath esistente.' }
        $file = Get-Item -LiteralPath $ExePath
        if ($file.PSProvider.Name -ne 'FileSystem' -or $file.Name -ine 'low_audio_latency.exe' -or $file.FullName.StartsWith('\\')) {
            throw 'Richiesto low_audio_latency.exe su disco locale. Non viene scaricato o certificato dallo script.'
        }
        Write-Host ('Eseguibile: ' + $file.FullName)
        Write-Host 'Scaricalo da spddl/LowAudioLatency. Se la versione richiede privilegi elevati, questa attivita non li fornisce.'
        if ((Read-Host 'Dopo il test manuale e la verifica della fonte, scrivi INSTALLA') -cne 'INSTALLA') { exit 0 }
        $exec = New-ScheduledTaskAction -Execute $file.FullName -WorkingDirectory $file.DirectoryName
        $trigger = New-ScheduledTaskTrigger -AtLogOn -User $user
        $principal = New-ScheduledTaskPrincipal -UserId $user -LogonType Interactive -RunLevel Limited
        $settings = New-ScheduledTaskSettingsSet -ExecutionTimeLimit ([TimeSpan]::Zero) -MultipleInstances IgnoreNew -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
        Register-ScheduledTask -TaskName $name -TaskPath '\' -Action $exec -Trigger $trigger -Principal $principal -Settings $settings -Description 'Prime Build v3.0 - LowAudioLatency user startup' -ErrorAction Stop | Out-Null
        Write-Host 'Attivita creata, non avviata ora. Verifica al prossimo accesso: processo, output e endpoint.'
    } else {
        if (-not $task) { Write-Host 'Attivita gia assente.'; exit 0 }
        if (-not (Test-PrimeBuildAudioTask $task $user)) { throw 'Attivita non riconosciuta: nessuna rimozione automatica.' }
        if ((Read-Host 'Scrivi RIMUOVI per eliminare solo questa attivita') -cne 'RIMUOVI') { exit 0 }
        Unregister-ScheduledTask -TaskName $name -TaskPath '\' -Confirm:$false -ErrorAction Stop
        Write-Host 'Avvio automatico rimosso. Chiudi manualmente il processo gia aperto per terminare la prova.'
    }
    exit 0
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
