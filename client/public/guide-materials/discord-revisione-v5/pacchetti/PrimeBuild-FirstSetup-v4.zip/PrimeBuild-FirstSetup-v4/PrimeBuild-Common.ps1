# Prime Build v3.0 - funzioni locali, nessuna modifica all'importazione.
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Test-PrimeBuildWindows {
    param([int]$Build, [int]$ProductType, [string]$Caption)
    return $Build -ge 26200 -and $ProductType -eq 1 -and $Caption -match 'Windows 11'
}

function Assert-PrimeBuildWindows {
    $os = Get-CimInstance Win32_OperatingSystem
    if (-not (Test-PrimeBuildWindows ([int]$os.BuildNumber) ([int]$os.ProductType) $os.Caption)) {
        throw 'Richiesto Windows 11 25H2 o successivo (build >= 26200), edizione client.'
    }
}

function Assert-PrimeBuildAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
        throw 'Questa operazione richiede una console amministratore. Nessuna modifica eseguita.'
    }
}

function Get-PrimeBuildExitHex {
    param([int]$Code)
    return [BitConverter]::ToUInt32([BitConverter]::GetBytes($Code), 0).ToString('X8')
}

function Test-PrimeBuildWingetSuccess {
    param([int]$Code)
    return (Get-PrimeBuildExitHex $Code) -in @('00000000', '8A150061', '8A15002B')
}
