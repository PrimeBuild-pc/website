@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "PB_SCRIPT_ROOT=%~dp0"
:: shortcut: il batch non supporta percorsi con !, usare un launcher PowerShell se necessario.
powershell -NoProfile -Command "if($env:PB_SCRIPT_ROOT.Contains('!') -or -not $env:TEMP -or $env:TEMP.Contains('!')){exit 1}else{exit 0}"
if errorlevel 1 (
  echo [ERRORE] Usa cartelle script/TEMP esistenti senza punto esclamativo.
  exit /b 1
)
setlocal EnableDelayedExpansion

:: --------------------------------------------------------------
:: PrimeBuild First Setup v3.0 - Windows 11 25H2+
:: --------------------------------------------------------------

:: Salva la codepage corrente per ripristinarla all'uscita
set "OLDCP="
for /f "tokens=2 delims=:" %%A in ('chcp') do for /f "tokens=1 delims=. " %%B in ("%%A") do set "OLDCP=%%B"
chcp 65001 >nul
Title PrimeBuild First Setup v3.0

powershell -NoProfile -Command "$o=Get-CimInstance Win32_OperatingSystem; if([int]$o.BuildNumber -ge 26200 -and $o.ProductType -eq 1 -and $o.Caption -match 'Windows 11'){exit 0}else{exit 1}"
if errorlevel 1 (
  echo [ERRORE] Richiesto Windows 11 25H2 o successivo, build 26200+ client.
  pause
  if defined OLDCP chcp %OLDCP% >nul
  exit /b 1
)
for %%F in (PrimeBuild-Common.ps1 PrimeBuild-AggiornaApp.ps1 PrimeBuild-DriverPolicy.ps1) do if not exist "%~dp0%%F" (
  echo [ERRORE] Manca %%F. Estrai tutto il pacchetto ZIP, non il solo BAT.
  pause
  if defined OLDCP chcp %OLDCP% >nul
  exit /b 1
)

:: --------------------------------------------------------------
:: Elevazione amministratore
:: fltmc non dipende dal servizio Server (net session puo fallire
:: anche da admin se il servizio e disabilitato -> loop UAC infinito)
:: --------------------------------------------------------------
fltmc >nul 2>&1
if not errorlevel 1 goto ADMIN_OK

echo Richiesta privilegi di amministratore...
set "SELF=%~f0"
powershell -NoProfile -Command "try { Start-Process -FilePath $env:SELF -Verb RunAs -ErrorAction Stop } catch { exit 1 }"
if errorlevel 1 (
  echo.
  echo [ERRORE] Elevazione annullata o non riuscita.
  echo Lo script richiede i privilegi di amministratore per funzionare.
  pause
)
if defined OLDCP chcp %OLDCP% >nul
exit /b

:ADMIN_OK

:: Le code di altre istanze non vengono cancellate.

set "QUEUE=%TEMP%\PrimeBuild-Queue-%RANDOM%%RANDOM%.txt"
set "TUNER=%TEMP%\PrimeBuild-Tuner-%RANDOM%%RANDOM%.txt"
type nul > "%QUEUE%"
if errorlevel 1 (
  echo [ERRORE] Impossibile creare la coda in TEMP.
  if defined OLDCP chcp %OLDCP% >nul
  exit /b 1
)
type nul > "%TUNER%"
if errorlevel 1 (
  echo [ERRORE] Impossibile creare la coda tuning in TEMP.
  del /q "%QUEUE%" >nul 2>&1
  if defined OLDCP chcp %OLDCP% >nul
  exit /b 1
)

:MENU
cls
echo ==============================================================
echo                 PRIMEBUILD - FIRST SETUP v3.0
echo           Gaming / low latency / post-install Windows
echo ==============================================================
echo  1. Dipendenze gaming - VC++ / DirectX / .NET
echo  2. Monitoring / benchmark / stability
echo  3. Launcher gaming / gaming tools
echo  4. Utility Windows
echo  5. Video / media
echo  6. Browser / produttivita
echo  7. Dev tools
echo  8. Tool tuning Windows - scegline UNO
echo  9. Tool Marius Heier - USB / polling / latency
echo 10. Rivedi coda e INSTALLA tutto
echo 11. Aggiorna app Winget - esclusi Epic, Battle.net, HWiNFO
echo 12. Escludi driver dai normali Windows Update
echo 13. Ripristina policy driver WU dal backup di questo tool
echo 14. Audio - driver supportati ed endpoint corretti
echo 15. Device Manager / virtualizzazione - guida sicura
echo 16. Ripara Windows - DISM + SFC
echo 17. Link driver ufficiali GPU / chipset
echo 18. Windows Update / Microsoft Store
echo 19. LatencyMon - cosa controllare
echo 20. Svuota coda software
echo 21. Verifica ID Winget della coda - diagnostica
echo 22. Stato licenza Windows
echo  0. Esci
echo ==============================================================
call :GETCHOICE
if "%X%"=="1" goto DEPS
if "%X%"=="2" goto MON
if "%X%"=="3" goto GAME
if "%X%"=="4" goto UTIL
if "%X%"=="5" goto MEDIA
if "%X%"=="6" goto PROD
if "%X%"=="7" goto DEV
if "%X%"=="8" goto TUNING
if "%X%"=="9" goto MARIUS
if "%X%"=="10" goto INSTALL
if "%X%"=="11" goto UPGRADE
if "%X%"=="12" goto BLOCKDRV
if "%X%"=="13" goto UNBLOCKDRV
if "%X%"=="14" goto AUDIO
if "%X%"=="15" goto DEVICES
if "%X%"=="16" goto REPAIR
if "%X%"=="17" goto DRIVERS
if "%X%"=="18" goto UPDATE
if "%X%"=="19" goto LATENCY
if "%X%"=="20" goto CLEARQUEUE
if "%X%"=="21" goto VERIFY
if "%X%"=="22" goto LICENSE
if "%X%"=="0" goto EXITAPP
goto MENU

:: --------------------------------------------------------------
:: INPUT MENU
:: Azzera sempre X (altrimenti Invio a vuoto ripete la scelta
:: precedente, anche di un altro sottomenu) e accetta solo cifre,
:: cosi virgolette / ^& / ^^ nell'input non rompono i confronti.
:: --------------------------------------------------------------
:GETCHOICE
set "X="
set /p "X=Scelta: "
if not defined X exit /b
set "INVALID=!X:0=!"
if defined INVALID set "INVALID=!INVALID:1=!"
if defined INVALID set "INVALID=!INVALID:2=!"
if defined INVALID set "INVALID=!INVALID:3=!"
if defined INVALID set "INVALID=!INVALID:4=!"
if defined INVALID set "INVALID=!INVALID:5=!"
if defined INVALID set "INVALID=!INVALID:6=!"
if defined INVALID set "INVALID=!INVALID:7=!"
if defined INVALID set "INVALID=!INVALID:8=!"
if defined INVALID set "INVALID=!INVALID:9=!"
if defined INVALID set "X="
exit /b

:: --------------------------------------------------------------
:: FUNZIONI CODA
:: --------------------------------------------------------------
:ADD
findstr /I /L /C:"%~1|%~2|" "%QUEUE%" >nul 2>&1
if not errorlevel 1 (
  echo.
  echo [OK] Gia presente in coda: %~3
  timeout /t 1 /nobreak >nul
  exit /b
)
>>"%QUEUE%" echo %~1^|%~2^|%~3
echo.
echo [AGGIUNTO] %~3
timeout /t 1 /nobreak >nul
exit /b

:SETTUNER
>"%TUNER%" echo %~1^|%~2^|%~3
echo.
echo [TUNING] Selezionato: %~3
echo Verranno sostituite eventuali selezioni tuning precedenti.
timeout /t 2 /nobreak >nul
exit /b

:CHECKWINGET
where winget >nul 2>&1
if errorlevel 1 (
  echo.
  echo [ERRORE] Winget non trovato. Aggiorna App Installer dal Microsoft Store.
  start "" "ms-windows-store://pdp/?ProductId=9NBLGGH4NNS1"
  exit /b 1
)
exit /b 0

:: --------------------------------------------------------------
:: DIPENDENZE
:: --------------------------------------------------------------
:DEPS
cls
echo ===== DIPENDENZE GAMING =====
echo Ogni voce viene aggiunta alla coda. 0 = indietro.
echo.
echo 1. Visual C++ 2008 x86 + x64
echo 2. Visual C++ 2010 x86 + x64
echo 3. Visual C++ 2012 x86 + x64
echo 4. Visual C++ 2013 x86 + x64
echo 5. Visual C++ 2015-2022 x86 + x64
echo 6. DirectX Runtime
echo 7. .NET Framework 3.5 - feature Windows
echo 8. .NET Desktop Runtime 8 x86 + x64
echo 9. .NET Desktop Runtime 10
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :ADD WINGET "Microsoft.VCRedist.2008.x86" "Visual C++ 2008 x86" & call :ADD WINGET "Microsoft.VCRedist.2008.x64" "Visual C++ 2008 x64" & goto DEPS)
if "%X%"=="2" (call :ADD WINGET "Microsoft.VCRedist.2010.x86" "Visual C++ 2010 x86" & call :ADD WINGET "Microsoft.VCRedist.2010.x64" "Visual C++ 2010 x64" & goto DEPS)
if "%X%"=="3" (call :ADD WINGET "Microsoft.VCRedist.2012.x86" "Visual C++ 2012 x86" & call :ADD WINGET "Microsoft.VCRedist.2012.x64" "Visual C++ 2012 x64" & goto DEPS)
if "%X%"=="4" (call :ADD WINGET "Microsoft.VCRedist.2013.x86" "Visual C++ 2013 x86" & call :ADD WINGET "Microsoft.VCRedist.2013.x64" "Visual C++ 2013 x64" & goto DEPS)
if "%X%"=="5" (call :ADD WINGET "Microsoft.VCRedist.2015+.x86" "Visual C++ 2015-2022 x86" & call :ADD WINGET "Microsoft.VCRedist.2015+.x64" "Visual C++ 2015-2022 x64" & goto DEPS)
if "%X%"=="6" (call :ADD WINGET "Microsoft.DirectX" "DirectX Runtime" & goto DEPS)
if "%X%"=="7" (call :ADD ACTION "NETFX3" ".NET Framework 3.5" & goto DEPS)
if "%X%"=="8" (call :ADD WINGET "Microsoft.DotNet.DesktopRuntime.8.x86" ".NET Desktop Runtime 8 x86" & call :ADD WINGET "Microsoft.DotNet.DesktopRuntime.8.x64" ".NET Desktop Runtime 8 x64" & goto DEPS)
if "%X%"=="9" (call :ADD WINGET "Microsoft.DotNet.DesktopRuntime.10" ".NET Desktop Runtime 10" & goto DEPS)
if "%X%"=="0" goto MENU
goto DEPS

:: --------------------------------------------------------------
:: MONITORING
:: --------------------------------------------------------------
:MON
cls
echo ===== MONITORING / BENCHMARK / STABILITY =====
echo 1. HWiNFO - download sito ufficiale, NON Winget
echo 2. CPU-Z
echo 3. GPU-Z
echo 4. LatencyMon
echo 5. CrystalDiskInfo
echo 6. CapFrameX
echo 7. OCCT Personal
echo 8. MSI Afterburner - download sito ufficiale
echo 9. RivaTuner Statistics Server - RTSS
echo 10. Fan Control
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :ADD URL "https://www.hwinfo.com/download/" "HWiNFO - sito ufficiale" & goto MON)
if "%X%"=="2" (call :ADD WINGET "CPUID.CPU-Z" "CPU-Z" & goto MON)
if "%X%"=="3" (call :ADD WINGET "TechPowerUp.GPU-Z" "GPU-Z" & goto MON)
if "%X%"=="4" (call :ADD WINGET "Resplendence.LatencyMon" "LatencyMon" & goto MON)
if "%X%"=="5" (call :ADD WINGET "CrystalDewWorld.CrystalDiskInfo" "CrystalDiskInfo" & goto MON)
if "%X%"=="6" (call :ADD WINGET "CXWorld.CapFrameX" "CapFrameX" & goto MON)
if "%X%"=="7" (call :ADD WINGET "OCBase.OCCT.Personal" "OCCT Personal" & goto MON)
if "%X%"=="8" (call :ADD URL "https://www.msi.com/Landing/afterburner/graphics-cards" "MSI Afterburner - sito ufficiale" & goto MON)
if "%X%"=="9" (call :ADD WINGET "Guru3D.RTSS" "RivaTuner Statistics Server" & goto MON)
if "%X%"=="10" (call :ADD WINGET "Rem0o.FanControl" "Fan Control" & goto MON)
if "%X%"=="0" goto MENU
goto MON

:: --------------------------------------------------------------
:: GAMING
:: --------------------------------------------------------------
:GAME
cls
echo ===== LAUNCHER GAMING / GAMING TOOLS =====
echo 1. Steam
echo 2. Epic Games Launcher
echo 3. EA App
echo 4. Ubisoft Connect
echo 5. GOG Galaxy - aggregatore
echo 6. Battle.net
echo 7. Xbox App
echo 8. Playnite - aggregatore librerie
echo 9. Heroic - Epic/GOG/Amazon
echo 10. Hydra Launcher
echo 11. LaunchBox - download ufficiale
echo 12. itch.io
echo 13. Discord
echo 14. DLSS Swapper
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :ADD WINGET "Valve.Steam" "Steam" & goto GAME)
if "%X%"=="2" (call :ADD WINGET "EpicGames.EpicGamesLauncher" "Epic Games Launcher" & goto GAME)
if "%X%"=="3" (call :ADD WINGET "ElectronicArts.EADesktop" "EA App" & goto GAME)
if "%X%"=="4" (call :ADD WINGET "Ubisoft.Connect" "Ubisoft Connect" & goto GAME)
if "%X%"=="5" (call :ADD WINGET "GOG.Galaxy" "GOG Galaxy" & goto GAME)
if "%X%"=="6" (call :ADD WINGET "Blizzard.BattleNet" "Battle.net" & goto GAME)
if "%X%"=="7" (call :ADD URL "https://www.xbox.com/apps/xbox-app-for-pc" "Xbox App - sito ufficiale" & goto GAME)
if "%X%"=="8" (call :ADD WINGET "Playnite.Playnite" "Playnite" & goto GAME)
if "%X%"=="9" (call :ADD WINGET "HeroicGamesLauncher.HeroicGamesLauncher" "Heroic Games Launcher" & goto GAME)
if "%X%"=="10" (call :ADD WINGET "HydraLauncher.Hydra" "Hydra Launcher" & goto GAME)
if "%X%"=="11" (call :ADD URL "https://www.launchbox-app.com/download" "LaunchBox - sito ufficiale" & goto GAME)
if "%X%"=="12" (call :ADD WINGET "ItchIo.Itch" "itch.io" & goto GAME)
if "%X%"=="13" (call :ADD WINGET "Discord.Discord" "Discord" & goto GAME)
if "%X%"=="14" (call :ADD URL "https://github.com/beeradmoore/dlss-swapper" "DLSS Swapper - fonte ufficiale" & goto GAME)
if "%X%"=="0" goto MENU
goto GAME

:: --------------------------------------------------------------
:: UTILITY
:: --------------------------------------------------------------
:UTIL
cls
echo ===== UTILITY WINDOWS =====
echo 1. 7-Zip
echo 2. Everything
echo 3. Bulk Crap Uninstaller
echo 4. PowerToys
echo 5. Notepad++
echo 6. WizTree
echo 7. ShareX
echo 8. Snappy Driver Installer Origin - driver offline/mancanti
echo 9. Driver Store Explorer - sito ufficiale, usare con backup
echo 10. DDU - sito ufficiale, solo se la pulizia e giustificata
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :ADD WINGET "7zip.7zip" "7-Zip" & goto UTIL)
if "%X%"=="2" (call :ADD WINGET "voidtools.Everything" "Everything" & goto UTIL)
if "%X%"=="3" (call :ADD WINGET "Klocman.BulkCrapUninstaller" "Bulk Crap Uninstaller" & goto UTIL)
if "%X%"=="4" (call :ADD WINGET "Microsoft.PowerToys" "PowerToys" & goto UTIL)
if "%X%"=="5" (call :ADD WINGET "Notepad++.Notepad++" "Notepad++" & goto UTIL)
if "%X%"=="6" (call :ADD WINGET "AntibodySoftware.WizTree" "WizTree" & goto UTIL)
if "%X%"=="7" (call :ADD WINGET "ShareX.ShareX" "ShareX" & goto UTIL)
if "%X%"=="8" (call :ADD WINGET "GlennDelahoy.SnappyDriverInstallerOrigin" "Snappy Driver Installer Origin" & goto UTIL)
if "%X%"=="9" (call :ADD URL "https://github.com/lostindark/DriverStoreExplorer" "Driver Store Explorer - fonte ufficiale" & goto UTIL)
if "%X%"=="10" (call :ADD URL "https://www.wagnardsoft.com/display-driver-uninstaller-ddu-" "DDU - fonte ufficiale" & goto UTIL)
if "%X%"=="0" goto MENU
goto UTIL

:: --------------------------------------------------------------
:: MEDIA
:: --------------------------------------------------------------
:MEDIA
cls
echo ===== VIDEO / MEDIA =====
echo 1. VLC
echo 2. OBS Studio
echo 3. FFmpeg
echo 4. HandBrake
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :ADD WINGET "VideoLAN.VLC" "VLC" & goto MEDIA)
if "%X%"=="2" (call :ADD WINGET "OBSProject.OBSStudio" "OBS Studio" & goto MEDIA)
if "%X%"=="3" (call :ADD WINGET "Gyan.FFmpeg" "FFmpeg" & goto MEDIA)
if "%X%"=="4" (call :ADD WINGET "HandBrake.HandBrake" "HandBrake" & goto MEDIA)
if "%X%"=="0" goto MENU
goto MEDIA

:: --------------------------------------------------------------
:: BROWSER / PROD
:: --------------------------------------------------------------
:PROD
cls
echo ===== BROWSER / PRODUTTIVITA =====
echo 1. Google Chrome
echo 2. Mozilla Firefox
echo 3. Brave
echo 4. Vivaldi
echo 5. Opera
echo 6. Zen Browser
echo 7. LibreWolf
echo 8. ONLYOFFICE Desktop Editors
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :ADD WINGET "Google.Chrome" "Google Chrome" & goto PROD)
if "%X%"=="2" (call :ADD WINGET "Mozilla.Firefox" "Mozilla Firefox" & goto PROD)
if "%X%"=="3" (call :ADD WINGET "Brave.Brave" "Brave" & goto PROD)
if "%X%"=="4" (call :ADD WINGET "Vivaldi.Vivaldi" "Vivaldi" & goto PROD)
if "%X%"=="5" (call :ADD WINGET "Opera.Opera" "Opera" & goto PROD)
if "%X%"=="6" (call :ADD WINGET "Zen-Team.Zen-Browser" "Zen Browser" & goto PROD)
if "%X%"=="7" (call :ADD WINGET "LibreWolf.LibreWolf" "LibreWolf" & goto PROD)
if "%X%"=="8" (call :ADD WINGET "ONLYOFFICE.DesktopEditors" "ONLYOFFICE Desktop Editors" & goto PROD)
if "%X%"=="0" goto MENU
goto PROD

:: --------------------------------------------------------------
:: DEV
:: --------------------------------------------------------------
:DEV
cls
echo ===== DEV TOOLS =====
echo 1. Git
echo 2. Visual Studio Code
echo 3. Python 3.14
echo 4. Node.js LTS
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :ADD WINGET "Git.Git" "Git" & goto DEV)
if "%X%"=="2" (call :ADD WINGET "Microsoft.VisualStudioCode" "Visual Studio Code" & goto DEV)
if "%X%"=="3" (call :ADD WINGET "Python.Python.3.14" "Python 3.14" & goto DEV)
if "%X%"=="4" (call :ADD WINGET "OpenJS.NodeJS.LTS" "Node.js LTS" & goto DEV)
if "%X%"=="0" goto MENU
goto DEV

:: --------------------------------------------------------------
:: TUNING - UNA SOLA SCELTA
:: --------------------------------------------------------------
:TUNING
cls
echo ===== TOOL TUNING WINDOWS =====
echo Nessun tool e obbligatorio. La disinstallazione di app inutili basta spesso.
echo Se scegli un tool, usa solo opzioni comprese e reversibili. Uno solo non significa sicuro.
echo.
echo 1. Chris Titus Tech WinUtil
echo 2. WinHance
echo 3. Wintoys
echo 4. Wagnardsoft WTools - download ufficiale
echo 5. Nessun tool tuning
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :SETTUNER URL "https://github.com/ChrisTitusTech/winutil" "WinUtil - istruzioni ufficiali, nessuna esecuzione remota" & goto MENU)
if "%X%"=="2" (call :SETTUNER URL "https://winhance.net/" "WinHance - istruzioni ufficiali, nessuna esecuzione remota" & goto MENU)
if "%X%"=="3" (call :SETTUNER MSSTORE "9P8LTPGCBZXD" "Wintoys" & goto MENU)
if "%X%"=="4" (call :SETTUNER URL "https://www.wagnardsoft.com/wtools" "Wagnardsoft WTools" & goto MENU)
if "%X%"=="5" (type nul > "%TUNER%" & echo Nessun tool tuning selezionato. & timeout /t 1 /nobreak >nul & goto MENU)
if "%X%"=="0" goto MENU
goto TUNING

:: --------------------------------------------------------------
:: MARIUS HEIER
:: --------------------------------------------------------------
:MARIUS
cls
echo ===== MARIUS HEIER - USB / INPUT / LATENCY =====
echo Questi tool sono diagnostici: vengono aperte le pagine ufficiali.
echo 1. CPU Direct - topologia USB / chip tra device e CPU
echo 2. DeepPoll - polling USB con ETW
echo 3. USB HID Analyzer - browser
echo 4. Rig Profiles
echo 5. Pagina completa Tools
echo 0. Indietro
call :GETCHOICE
if "%X%"=="1" (call :ADD URL "https://tools.mariusheier.com/cpudirect.html" "Marius CPU Direct" & goto MARIUS)
if "%X%"=="2" (call :ADD URL "https://tools.mariusheier.com/deeppoll.html" "Marius DeepPoll" & goto MARIUS)
if "%X%"=="3" (call :ADD URL "https://tools.mariusheier.com/poll_checker.html" "Marius USB HID Analyzer" & goto MARIUS)
if "%X%"=="4" (call :ADD URL "https://tools.mariusheier.com/rig.html" "Marius Rig Profiles" & goto MARIUS)
if "%X%"=="5" (call :ADD URL "https://tools.mariusheier.com/" "Marius Heier Tools" & goto MARIUS)
if "%X%"=="0" goto MENU
goto MARIUS

:: --------------------------------------------------------------
:: REVIEW / INSTALL
:: --------------------------------------------------------------
:INSTALL
cls
echo ===== CODA PRIMEBUILD =====
set "HAS=0"
for /f "usebackq tokens=1,2,* delims=|" %%A in ("%QUEUE%") do (
  echo - %%C
  set "HAS=1"
)
for /f "usebackq tokens=1,2,* delims=|" %%A in ("%TUNER%") do (
  echo - [TUNING] %%C
  set "HAS=1"
)
if "!HAS!"=="0" (
  echo.
  echo Coda vuota.
  pause
  goto MENU
)
echo.
echo NOTA: le voci "sito ufficiale" aprono il download nel browser e richiedono conferma manuale.
echo I tool tuning possono modificare Windows: usane uno solo e leggi le opzioni prima di applicarle.
echo Alcuni installer possono aprire una finestra propria e richiedere attesa.
echo Le pagine aperte non certificano l'installazione o la sicurezza dei tweak scelti.
echo.
choice /C SN /N /M "Confermi installazione/apertura di tutta la coda? [S/N]: "
if errorlevel 2 goto MENU

call :CHECKWINGET
:: Winget puo non servire se ci sono solo URL, quindi continuiamo anche se manca.

set "FAILCOUNT=0"
echo.
echo ===== ESECUZIONE CODA =====
call :INSTALL_FILE "%QUEUE%"
call :INSTALL_FILE "%TUNER%"
echo.
if !FAILCOUNT! GTR 0 (
  echo [ATTENZIONE] Voci non riuscite: !FAILCOUNT!
  echo La coda NON viene svuotata cosi puoi riprovare. Usa l'opzione 20 per azzerarla.
) else (
  echo Tutte le voci sono state elaborate senza errori.
  type nul > "%QUEUE%"
  type nul > "%TUNER%"
)
pause
goto MENU

:INSTALL_FILE
if not exist "%~1" exit /b
for /f "usebackq tokens=1,2,* delims=|" %%A in ("%~1") do call :DO_ITEM "%%A" "%%B" "%%C"
exit /b

:: --------------------------------------------------------------
:: Esecuzione singola voce.
:: Uso goto invece di blocchi ( ) annidati: dentro un blocco
:: %errorlevel% verrebbe congelato al parsing.
:: --------------------------------------------------------------
:DO_ITEM
echo.
echo --------------------------------------------------------------
echo %~3
if /I "%~1"=="WINGET" goto DO_WINGET
if /I "%~1"=="MSSTORE" goto DO_MSSTORE
if /I "%~1"=="URL" goto DO_URL
if /I "%~1"=="ACTION" goto DO_ACTION
echo [WARN] Tipo di voce non riconosciuto: %~1
set /a FAILCOUNT+=1
exit /b

:DO_WINGET
where winget >nul 2>&1
if errorlevel 1 (
  echo [WARN] Winget assente: salto %~3
  set /a FAILCOUNT+=1
  exit /b
)
winget install --id "%~2" -e --source winget --silent --accept-package-agreements --accept-source-agreements --disable-interactivity
call :WINGET_RC "%errorlevel%" "%~3"
exit /b

:DO_MSSTORE
where winget >nul 2>&1
if errorlevel 1 (
  echo [WARN] Winget assente: salto %~3
  set /a FAILCOUNT+=1
  exit /b
)
winget install --id "%~2" -e --source msstore --accept-package-agreements --accept-source-agreements
call :WINGET_RC "%errorlevel%" "%~3"
exit /b

:DO_URL
echo Apro pagina ufficiale: %~2
start "" "%~2"
if errorlevel 1 (
  echo [WARN] Apertura pagina non riuscita: %~3
  set /a FAILCOUNT+=1
)
exit /b

:DO_ACTION
if /I "%~2"=="NETFX3" (
  DISM /Online /Enable-Feature /FeatureName:NetFx3 /All /NoRestart
  set "DISMRC=!errorlevel!"
  if "!DISMRC!"=="3010" (
    echo [OK] .NET Framework 3.5 abilitato, riavvio richiesto.
  ) else if not "!DISMRC!"=="0" (
    echo [WARN] Abilitazione .NET Framework 3.5 non riuscita: !DISMRC!
    set /a FAILCOUNT+=1
  )
  exit /b
)
echo [WARN] Azione non riconosciuta: %~2
set /a FAILCOUNT+=1
exit /b

:: --------------------------------------------------------------
:: Interpreta l'exit code di winget.
:: 0x8A150061 = pacchetto gia installato
:: 0x8A15002B = nessun aggiornamento applicabile
:: Non sono errori: non vanno segnalati come WARN.
:: --------------------------------------------------------------
:WINGET_RC
set "RC=%~1"
if "%RC%"=="0" (
  echo [OK] %~2
  exit /b
)
if "%RC%"=="-1978335135" (
  echo [OK] Gia installato: %~2
  exit /b
)
if "%RC%"=="-1978335189" (
  echo [OK] Gia aggiornato: %~2
  exit /b
)
echo [WARN] Operazione non riuscita: %~2  - codice %RC%
set /a FAILCOUNT+=1
exit /b

:: --------------------------------------------------------------
:: VERIFICA ID WINGET
:: --------------------------------------------------------------
:VERIFY
cls
echo ===== VERIFICA ID WINGET IN CODA =====
call :CHECKWINGET
if errorlevel 1 (pause & goto MENU)
echo Controllo che ogni ID esista nei repository. Puo richiedere qualche minuto.
echo.
set "MISS=0"
set "CHECKED=0"
for %%F in ("%QUEUE%" "%TUNER%") do for /f "usebackq tokens=1,2,* delims=|" %%A in ("%%~F") do (
  if /I "%%A"=="WINGET" call :VERIFY_ONE "%%B" "%%C" winget
  if /I "%%A"=="MSSTORE" call :VERIFY_ONE "%%B" "%%C" msstore
)
echo.
if "!CHECKED!"=="0" (
  echo Nessuna voce Winget in coda da verificare.
) else (
  echo Verificate !CHECKED! voci - ID non trovati: !MISS!
)
pause
goto MENU

:VERIFY_ONE
set /a CHECKED+=1
winget show --id "%~1" -e --source "%~3" --accept-source-agreements >nul 2>&1
if errorlevel 1 goto VERIFY_KO
echo [OK]  %~2
exit /b
:VERIFY_KO
echo [KO]  %~2  --^> ID non trovato: %~1
set /a MISS+=1
exit /b

:: --------------------------------------------------------------
:: WINGET UPGRADE DA INVENTARIO, SENZA MODIFICARE I PIN
:: --------------------------------------------------------------
:UPGRADE
cls
call :CHECKWINGET
if errorlevel 1 (pause & goto MENU)
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PrimeBuild-AggiornaApp.ps1"
if errorlevel 1 echo [ATTENZIONE] Aggiornamenti non completati. Leggi gli errori sopra.
pause
goto MENU

:: --------------------------------------------------------------
:: DRIVER WINDOWS UPDATE
:: --------------------------------------------------------------
:BLOCKDRV
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PrimeBuild-DriverPolicy.ps1" -Action Block
if errorlevel 1 echo [ERRORE] Policy non applicata o stato da verificare; non forzare il registro.
pause
goto MENU

:UNBLOCKDRV
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0PrimeBuild-DriverPolicy.ps1" -Action Restore
if errorlevel 1 echo [ERRORE] Nessun ripristino certificato: leggi il messaggio e conserva il backup.
pause
goto MENU

:: --------------------------------------------------------------
:: AUDIO LOW LATENCY
:: --------------------------------------------------------------
:AUDIO
cls
echo ==============================================================
echo       AUDIO LOW-LATENCY - BASELINE PRIMEBUILD
echo ==============================================================
echo Obiettivo: selezionare uscita e ingresso corretti in Windows E nelle app.
echo Non devi disabilitare tutte le altre uscite del PC.
echo.
echo DRIVER AUDIO:
echo 1. Parti dal driver supportato dal produttore di MB/notebook/dispositivo.
echo 2. Realtek non e automaticamente lento; DSP e filtri vanno valutati separatamente.
echo 3. Il generico Microsoft e solo un confronto se compatibile, non una cura universale.
echo 4. Non rimuovere Intel SST, componenti OEM o driver bus alla cieca.
echo 5. Baseline senza EQ: effetti/spatial extra OFF. Con Equalizer APO, verifica APO attivo.
echo 6. Se usi EQ, non spegnere anche il percorso effetti che lo ospita.
echo.
echo ENDPOINT DA DISABILITARE SE NON USATI:
echo - NVIDIA/AMD/Intel HDMI/DisplayPort Audio se non usi audio dal monitor/TV.
echo - Audio cuffie/mic creato dal controller; NON disabilitare controller/HID.
echo - Mic webcam/monitor e altri endpoint duplicati.
echo - Realtek/onboard audio se usi headset USB, DAC o scheda audio esterna.
echo - Audio di headset USB extra che non usi.
echo.
echo Policy WU opzionale nel menu 12: evita alcune sostituzioni, non tutte.
echo Non e un tweak di latenza. Va ripristinata dal suo backup se non serve piu.
echo ==============================================================
start "" devmgmt.msc
start "" mmsys.cpl
pause
goto MENU

:: --------------------------------------------------------------
:: DEVICE MANAGER / VM
:: --------------------------------------------------------------
:DEVICES
cls
echo ==============================================================
echo         DEVICE CLEANUP - SOLO DISPOSITIVI NON USATI
echo ==============================================================
echo In Device Manager puoi disabilitare, SE NON SERVONO:
echo - Wi-Fi se usi solo Ethernet; Bluetooth se non usi periferiche BT.
echo - Seconda NIC / adattatori di rete inutilizzati.
echo - Audio HDMI/DP GPU, webcam/mic, card reader non usati.
echo - Audio onboard se usi solo DAC / scheda audio / headset USB.
echo - Solo endpoint audio dei controller, NON controller/HID.
echo - Adattatori virtuali Hyper-V / VMware / VirtualBox non usati.
echo.
echo Se NON usi VM, WSL2, Sandbox, Docker o emulatori basati su hypervisor:
echo apri Funzionalita Windows e valuta di togliere:
echo - Hyper-V
echo - Virtual Machine Platform
echo - Windows Hypervisor Platform
echo - Windows Sandbox
echo - Windows Subsystem for Linux se non lo usi
echo.
echo NON disabilitare alla cieca: ACPI, PCI Root, SMBus, xHCI/USB Root Hub,
echo NVMe/SATA/storage, TPM, GPIO, MEI/PSP, timer o dispositivi chipset.
echo Le funzioni di virtualizzazione possono essere usate anche da software di sicurezza:
echo questa voce NON disabilita automaticamente VBS/Memory Integrity.
echo ==============================================================
start "" devmgmt.msc
start "" optionalfeatures.exe
start "" mmsys.cpl
pause
goto MENU

:: --------------------------------------------------------------
:: REPAIR
:: --------------------------------------------------------------
:REPAIR
cls
echo ===== RIPARAZIONE WINDOWS =====
echo Verranno eseguiti nell'ordine:
echo 1. DISM /Online /Cleanup-Image /RestoreHealth
echo 2. sfc /scannow
echo.
echo DISM puo restare a lungo sulla stessa percentuale: e normale, non e bloccato.
echo Il tempo dipende da macchina, rete e stato del sistema. Non interrompere alla cieca.
echo.
choice /C SN /N /M "Continuare? [S/N]: "
if errorlevel 2 goto MENU
DISM /Online /Cleanup-Image /RestoreHealth
if errorlevel 1 echo [WARN] DISM ha restituito un errore. Controlla C:\Windows\Logs\DISM\dism.log
sfc /scannow
if errorlevel 1 echo [WARN] SFC ha restituito un errore. Controlla output e C:\Windows\Logs\CBS\CBS.log
echo.
echo Comandi terminati: leggi gli esiti, non significa che ogni problema sia risolto.
echo Riavvia se richiesto o se sono stati corretti file.
pause
goto MENU

:: --------------------------------------------------------------
:: DRIVER LINKS / UPDATE
:: --------------------------------------------------------------
:DRIVERS
start "" "https://www.amd.com/en/support/download/drivers.html"
start "" "https://www.intel.com/content/www/us/en/download-center/home.html"
start "" "https://www.nvidia.com/Download/index.aspx"
echo.
echo Usa chipset/GPU dal produttore. Per LAN/Wi-Fi/BT/MEI usa il sito della MB/notebook quando serve.
echo Per macchine senza rete o con driver mancanti: Snappy Driver Installer Origin, menu 4 voce 8.
pause
goto MENU

:UPDATE
start "" ms-settings:windowsupdate
start "" ms-windows-store://downloadsandupdates
pause
goto MENU

:: --------------------------------------------------------------
:: STATO LICENZA
:: --------------------------------------------------------------
:LICENSE
cls
echo ===== STATO LICENZA WINDOWS =====
echo Verifica che la licenza OEM/retail risulti attiva - utile dopo un
echo cambio hardware o una reinstallazione pulita.
echo.
cscript //nologo "%SystemRoot%\System32\slmgr.vbs" /xpr
echo.
cscript //nologo "%SystemRoot%\System32\slmgr.vbs" /dli
echo.
echo Se risulta non attivata: verifica di aver eseguito l'accesso con
echo l'account Microsoft collegato alla licenza digitale, oppure usa
echo Impostazioni ^> Sistema ^> Attivazione ^> Risoluzione dei problemi.
start "" ms-settings:activation
pause
goto MENU

:: --------------------------------------------------------------
:: LATENCYMON
:: --------------------------------------------------------------
:LATENCY
cls
echo ==============================================================
echo                LATENCYMON - CHECK RAPIDO
echo ==============================================================
echo 1. Baseline separata senza altri test/monitoraggi; documenta durata e opzioni.
echo 2. Prova mirata durante il sintomo solo per indagare quel caso: cambia il carico.
echo 3. Main/Stats/Drivers/CPUs/Processes: massimo, conteggi e totali sono diversi.
echo 4. Il verdetto non misura input lag gaming. DPC count alto non prova un problema.
echo 5. Leggi il PDF LatencyMon e le FAQ: il monitor stesso puo perturbare il test.
echo.
echo DRIVER COMUNI DA RICONOSCERE:
echo - Realtek / RTKVHD*.sys   = audio Realtek
echo - nvlddmkm.sys            = NVIDIA
echo - amdkmdag.sys            = AMD GPU
echo - dxgkrnl.sys             = stack grafico DirectX
echo - ndis.sys / tcpip.sys    = rete
echo - USBXHCI.SYS             = USB controller
echo - HDAudBus.sys            = High Definition Audio bus
echo - storport.sys            = storage
echo - ACPI.sys                = ACPI / firmware / power path
echo - Wdf01000.sys            = framework: cerca il device/driver sottostante
echo.
echo Confronta PRIMA/DOPO ogni modifica nelle stesse condizioni.
echo ==============================================================
start "" "https://www.resplendence.com/latencymon"
pause
goto MENU

:CLEARQUEUE
type nul > "%QUEUE%"
type nul > "%TUNER%"
echo.
echo Coda svuotata.
timeout /t 1 /nobreak >nul
goto MENU

:EXITAPP
del /q "%QUEUE%" >nul 2>&1
del /q "%TUNER%" >nul 2>&1
if defined OLDCP chcp %OLDCP% >nul
endlocal
exit /b
