[CmdletBinding()]
param([ValidateSet('Status','DisableAcceleration','Restore')][string]$Action = 'Status')
. "$PSScriptRoot\PrimeBuild-Common.ps1"

function Test-PrimeBuildMouseBackup {
    param($Backup, [string]$Machine, [string]$User)
    return $Backup.Schema -eq 1 -and $Backup.Machine -ceq $Machine -and $Backup.User -ceq $User -and
        @($Backup.Parameters).Count -eq 3 -and
        $Backup.Parameters[0] -is [int] -and $Backup.Parameters[0] -ge 0 -and
        $Backup.Parameters[1] -is [int] -and $Backup.Parameters[1] -ge 0 -and
        $Backup.Parameters[2] -in @(0,1,2)
}

try {
    Assert-PrimeBuildWindows
    Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class PrimeBuildMouseNative {
    [DllImport("user32.dll", SetLastError=true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    public static extern bool SystemParametersInfo(uint action, uint parameter,
        [In, Out] int[] values, uint flags);
}
'@
    $current = [int[]]@(0,0,0)
    if (-not [PrimeBuildMouseNative]::SystemParametersInfo(0x0003, 0, $current, 0)) {
        throw 'Impossibile leggere i parametri mouse.'
    }
    Write-Host ('Soglie e accelerazione del puntatore Windows: ' + ($current -join ', '))
    Write-Host 'Non abilita Raw Input; non cambia DPI, velocita cursore, curve, FSO o interrupt USB.'
    if ($Action -eq 'Status') { exit 0 }
    $machine = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid
    $user = [Security.Principal.WindowsIdentity]::GetCurrent().User.Value
    $backupFile = Join-Path $env:LOCALAPPDATA 'PrimeBuild\Backups\mouse-parameters.json'
    if ((Read-Host "Scrivi $Action per confermare sul profilo utente corrente") -cne $Action) { exit 0 }
    if ($Action -eq 'DisableAcceleration') {
        if (Test-Path -LiteralPath $backupFile) {
            throw 'Backup gia presente: usa Restore prima di applicare di nuovo. Non lo sovrascrivo.'
        }
        $backup = [pscustomobject]@{ Schema=1; Machine=$machine; User=$user; Parameters=@($current) }
        New-Item -ItemType Directory -Path (Split-Path $backupFile) -Force | Out-Null
        $stream = [IO.File]::Open($backupFile, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
        try {
            $bytes = [Text.Encoding]::UTF8.GetBytes(($backup | ConvertTo-Json))
            $stream.Write($bytes, 0, $bytes.Length)
        } finally { $stream.Dispose() }
        $target = [int[]]@(0,0,0)
    } else {
        if (-not (Test-Path -LiteralPath $backupFile)) { throw 'Backup assente: nessun ripristino inventato.' }
        $backup = Get-Content -LiteralPath $backupFile -Raw | ConvertFrom-Json
        if (-not (Test-PrimeBuildMouseBackup $backup $machine $user)) { throw 'Backup non valido o di un altro PC/utente.' }
        if (($current -join ',') -ne '0,0,0' -and ($current -join ',') -ne ($backup.Parameters -join ',')) {
            throw 'Parametri cambiati dopo lo script: verifica manualmente prima di ripristinare.'
        }
        $target = [int[]]$backup.Parameters
    }
    # SPI_SETMOUSE aggiorna solo i tre parametri e notifica le applicazioni.
    if (-not [PrimeBuildMouseNative]::SystemParametersInfo(0x0004, 0, $target, 3)) {
        throw "Scrittura non riuscita: conserva il backup $backupFile e controlla le impostazioni mouse."
    }
    $check = [int[]]@(0,0,0)
    if (-not [PrimeBuildMouseNative]::SystemParametersInfo(0x0003, 0, $check, 0) -or
        ($check -join ',') -ne ($target -join ',')) { throw 'Verifica fallita: conserva il backup.' }
    if ($Action -eq 'Restore') {
        $archive = Join-Path (Split-Path $backupFile) ('mouse-restored-' + [guid]::NewGuid() + '.json')
        Move-Item -LiteralPath $backupFile -Destination $archive
        Write-Host "Parametri originali ripristinati; archivio: $archive"
    } else { Write-Host "Accelerazione puntatore disattivata. Backup per Restore: $backupFile" }
    exit 0
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
