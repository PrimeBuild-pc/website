@echo off
setlocal EnableExtensions DisableDelayedExpansion
Title Prime Build - Avvio strumenti v4
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
for %%F in (PrimeBuild-FirstSetup.bat PrimeBuild-Common.ps1 PrimeBuild-AggiornaApp.ps1 PrimeBuild-DriverPolicy.ps1 PrimeBuild-Diagnostica.ps1 PrimeBuild-Mouse.ps1 PrimeBuild-LowAudioLatency-Startup.ps1 PrimeBuild-USB.ps1 LEGGIMI.txt) do if not exist "%~dp0%%F" (
  echo [ERRORE] Manca %%F. Estrai tutto lo ZIP in una cartella nuova.
  pause
  exit /b 1
)
if not exist "%PS%" (
  echo [ERRORE] Windows PowerShell non disponibile su questa macchina.
  pause
  exit /b 1
)

:MENU
cls
echo ==============================================================
echo                    PRIME BUILD - STRUMENTI
echo ==============================================================
echo Avvia normalmente con doppio clic. Non aprire i file PS1.
echo Mouse e audio operano sul tuo utente: non usare un altro account.
echo.
echo 1. First Setup - app, aggiornamenti e policy driver
echo 2. Diagnostica - sola lettura
echo 3. Input - mouse e inventario USB
echo 4. LowAudioLatency - avvio automatico per utente
echo 5. Leggi le istruzioni
echo 0. Esci
choice /C 123450 /N /M "Scelta: "
if errorlevel 255 goto INPUT_ERROR
set "PICK=%errorlevel%"
if "%PICK%"=="1" goto SETUP
if "%PICK%"=="2" goto DIAGNOSTICA
if "%PICK%"=="3" goto MOUSE
if "%PICK%"=="4" goto AUDIO
if "%PICK%"=="5" goto ISTRUZIONI
exit /b 0

:SETUP
call "%~dp0PrimeBuild-FirstSetup.bat"
if errorlevel 1 echo [ATTENZIONE] First Setup ha segnalato un errore. Leggi i messaggi nella sua finestra.
pause
goto MENU

:ISTRUZIONI
notepad.exe "%~dp0LEGGIMI.txt"
goto MENU

:DIAGNOSTICA
cls
echo ===== DIAGNOSTICA IN SOLA LETTURA =====
echo 1. MMCSS
echo 2. BCD - richiede amministratore
echo 3. Rete e policy QoS
echo 4. Inventario USB
echo 0. Torna al menu
choice /C 12340 /N /M "Scelta: "
if errorlevel 255 goto INPUT_ERROR
set "PICK=%errorlevel%"
if "%PICK%"=="5" goto MENU
if "%PICK%"=="0" exit /b 0
set "PB_SCRIPT=PrimeBuild-Diagnostica.ps1"
set "PB_RETURN=DIAGNOSTICA"
if "%PICK%"=="1" set "PB_ARGS=-Section MMCSS"
if "%PICK%"=="2" set "PB_ARGS=-Section BCD"
if "%PICK%"=="3" set "PB_ARGS=-Section Network"
if "%PICK%"=="4" set "PB_ARGS=-Section USB"
if "%PICK%"=="2" echo Per BCD: se mancano i privilegi, chiudi e riapri questo BAT con Esegui come amministratore.
goto RUN

:MOUSE
cls
echo ===== INPUT - MOUSE E USB =====
echo Non abilita Raw Input e non annulla il vecchio pack.
echo 1. Mostra lo stato
echo 2. Disattiva accelerazione - con backup e conferma
echo 3. Ripristina dal backup - con conferma
echo 4. Inventario USB - sola lettura, non misura latenza
echo 0. Torna al menu
choice /C 12340 /N /M "Scelta: "
if errorlevel 255 goto INPUT_ERROR
set "PICK=%errorlevel%"
if "%PICK%"=="5" goto MENU
if "%PICK%"=="0" exit /b 0
set "PB_SCRIPT=PrimeBuild-Mouse.ps1"
set "PB_RETURN=MOUSE"
if "%PICK%"=="1" set "PB_ARGS=-Action Status"
if "%PICK%"=="2" set "PB_ARGS=-Action DisableAcceleration"
if "%PICK%"=="3" set "PB_ARGS=-Action Restore"
if "%PICK%"=="4" (
  set "PB_SCRIPT=PrimeBuild-USB.ps1"
  set "PB_ARGS="
)
goto RUN

:AUDIO
cls
echo ===== LOWAUDIOLATENCY - AVVIO AUTOMATICO =====
echo Prima prova manualmente il tool ufficiale e la stabilita audio.
echo Non viene scaricato alcun EXE. Non usare un altro account.
echo 1. Mostra lo stato dell'attivita
echo 2. Crea l'avvio - scegli l'EXE nella finestra e conferma
echo 3. Rimuovi l'avvio - con conferma
echo 0. Torna al menu
choice /C 1230 /N /M "Scelta: "
if errorlevel 255 goto INPUT_ERROR
set "PICK=%errorlevel%"
if "%PICK%"=="4" goto MENU
if "%PICK%"=="0" exit /b 0
set "PB_SCRIPT=PrimeBuild-LowAudioLatency-Startup.ps1"
set "PB_RETURN=AUDIO"
if "%PICK%"=="1" set "PB_ARGS=-Action Status"
if "%PICK%"=="2" set "PB_ARGS=-Action Install"
if "%PICK%"=="3" set "PB_ARGS=-Action Remove"
goto RUN

:RUN
:: Bypass vale solo per questo processo; non modifica policy persistenti o GPO.
"%PS%" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0%PB_SCRIPT%" %PB_ARGS%
set "RC=%errorlevel%"
if not "%RC%"=="0" (
  echo.
  echo [ATTENZIONE] Operazione non completata, codice %RC%. Leggi l'errore sopra.
  echo Se una policy aziendale o la sicurezza blocca l'avvio, fermati e chiedi supporto.
)
echo.
pause
goto %PB_RETURN%

:INPUT_ERROR
echo [ERRORE] Impossibile leggere la scelta. Nessuna nuova operazione avviata.
exit /b 1
