[CmdletBinding()]
param()
. "$PSScriptRoot\PrimeBuild-Common.ps1"

try {
    Assert-PrimeBuildWindows
    Write-Output 'Prime Build - inventario USB in sola lettura, non un benchmark.'
    Write-Output 'Prima di condividere il report, rimuovi identificativi e nomi personali.'
    Write-Output "`n=== USB ==="
    Get-PnpDevice -PresentOnly | Where-Object { $_.Class -in @('USB','HIDClass','Mouse') } |
        Format-Table Status, Class, FriendlyName, InstanceId -AutoSize | Out-String | Write-Output
    Write-Output 'Inventario PnP, non topologia completa e non misura input lag. Usa USBTreeView per i collegamenti.'
    exit 0
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
