[CmdletBinding()]
param([ValidateSet('Status','Block','Restore')][string]$Action = 'Status')
. "$PSScriptRoot\PrimeBuild-Common.ps1"

function Test-PrimeBuildPolicyBackup {
    param($Backup, [string]$Machine)
    return $Backup.Schema -eq 1 -and $Backup.Machine -ceq $Machine -and
        $Backup.Present -is [bool] -and $Backup.Value -is [int] -and $Backup.Value -in @(0,1)
}

$path = 'HKLM:\SOFTWARE\Policies\Microsoft\Windows\WindowsUpdate'
$name = 'ExcludeWUDriversInQualityUpdate'
$backupFile = Join-Path $env:LOCALAPPDATA 'PrimeBuild\Backups\WU-driver-policy.json'
try {
    Assert-PrimeBuildWindows
    $machine = (Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Cryptography' -Name MachineGuid).MachineGuid
    $key = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
    $present = $null -ne $key -and $key.GetValueNames() -contains $name
    $value = 0
    if ($present) {
        if ($key.GetValueKind($name) -ne [Microsoft.Win32.RegistryValueKind]::DWord) { throw 'Policy non DWORD: gestione manuale richiesta.' }
        $value = $key.GetValue($name)
        if ($value -notin @(0,1)) { throw 'Valore policy non standard: nessuna modifica automatica.' }
    }
    Write-Host "Policy presente: $present; valore: $value. Backup: $backupFile"
    Write-Host 'Policy globale: non blocca ogni meccanismo di installazione driver. Non disabilita Windows Update.'
    if ($Action -eq 'Status') { exit 0 }
    Assert-PrimeBuildAdmin
    if ((Read-Host "Scrivi $Action per confermare") -cne $Action) { Write-Host 'Annullato.'; exit 0 }
    if ($Action -eq 'Block') {
        if (Test-Path -LiteralPath $backupFile) {
            $backup = Get-Content -LiteralPath $backupFile -Raw | ConvertFrom-Json
            if (-not (Test-PrimeBuildPolicyBackup $backup $machine)) { throw 'Backup non valido o appartenente a un altro PC.' }
            if (-not $present -or $value -ne 1) { throw 'Policy cambiata dopo il backup: non sovrascrivo uno stato diverso.' }
        } else {
            $backup = [pscustomobject]@{ Schema=1; Machine=$machine; Present=[bool]$present; Value=[int]$value }
            New-Item -ItemType Directory -Path (Split-Path $backupFile) -Force | Out-Null
            $stream = [IO.File]::Open($backupFile, [IO.FileMode]::CreateNew, [IO.FileAccess]::Write)
            try {
                $bytes = [Text.Encoding]::UTF8.GetBytes(($backup | ConvertTo-Json))
                $stream.Write($bytes, 0, $bytes.Length)
            } finally { $stream.Dispose() }
        }
        if (-not (Test-Path -LiteralPath $path)) { New-Item -Path $path -Force | Out-Null }
        New-ItemProperty -Path $path -Name $name -Value 1 -PropertyType DWord -Force | Out-Null
        if ((Get-ItemProperty -Path $path -Name $name).$name -ne 1) { throw 'Verifica della scrittura fallita.' }
        Write-Host 'Policy applicata. Conserva il backup e usa Restore dopo il setup se non vuoi mantenerla.'
    } else {
        if (-not (Test-Path -LiteralPath $backupFile)) { throw 'Nessun backup: non invento lo stato precedente.' }
        $backup = Get-Content -LiteralPath $backupFile -Raw | ConvertFrom-Json
        if (-not (Test-PrimeBuildPolicyBackup $backup $machine)) { throw 'Backup non valido o appartenente a un altro PC.' }
        $alreadyOriginal = $present -eq $backup.Present -and (-not $present -or $value -eq $backup.Value)
        if ((-not $present -or $value -ne 1) -and -not $alreadyOriginal) {
            throw 'La policy non e piu quella applicata: verifica manualmente prima di ripristinare.'
        }
        if ($backup.Present) {
            New-ItemProperty -Path $path -Name $name -Value ([int]$backup.Value) -PropertyType DWord -Force | Out-Null
        } elseif ($present) {
            Remove-ItemProperty -Path $path -Name $name
        }
        $checkKey = Get-Item -LiteralPath $path -ErrorAction SilentlyContinue
        $checkPresent = $null -ne $checkKey -and $checkKey.GetValueNames() -contains $name
        if ($checkPresent -ne $backup.Present -or
            ($checkPresent -and ($checkKey.GetValueKind($name) -ne [Microsoft.Win32.RegistryValueKind]::DWord -or
            $checkKey.GetValue($name) -ne $backup.Value))) { throw 'Verifica del ripristino fallita: conserva il backup.' }
        $archive = Join-Path (Split-Path $backupFile) ('WU-driver-policy-restored-' + [guid]::NewGuid() + '.json')
        Move-Item -LiteralPath $backupFile -Destination $archive
        Write-Host "Stato originale della sola policy ripristinato. Backup archiviato: $archive"
    }
    exit 0
} catch {
    Write-Error $_ -ErrorAction Continue
    exit 1
}
