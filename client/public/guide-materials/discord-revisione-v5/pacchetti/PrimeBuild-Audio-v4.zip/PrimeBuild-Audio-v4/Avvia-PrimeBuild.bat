@echo off
setlocal EnableExtensions DisableDelayedExpansion
Title Prime Build - Avvio strumenti v4
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
for %%F in (PrimeBuild-Common.ps1 PrimeBuild-LowAudioLatency-Startup.ps1 LEGGIMI.txt) do if not exist "%~dp0%%F" (
  echo [ERRORE] Manca %%F. Estrai tutto lo ZIP in una cartella nuova.
  pause
  exit /b 1
)
if not exist "%PS%" (
  echo [ERRORE] Windows PowerShell non disponibile su questa macchina.
  pause
  exit /b 1
)

goto AUDIO

:AUDIO
cls
echo ===== LOWAUDIOLATENCY - AVVIO AUTOMATICO =====
echo Prima prova manualmente il tool ufficiale e la stabilita audio.
echo Non viene scaricato alcun EXE. Non usare un altro account.
echo 1. Mostra lo stato dell'attivita
echo 2. Crea l'avvio - scegli l'EXE nella finestra e conferma
echo 3. Rimuovi l'avvio - con conferma
echo 0. Esci
choice /C 1230 /N /M "Scelta: "
if errorlevel 255 goto INPUT_ERROR
set "PICK=%errorlevel%"
if "%PICK%"=="4" exit /b 0
if "%PICK%"=="0" exit /b 0
set "PB_SCRIPT=PrimeBuild-LowAudioLatency-Startup.ps1"
set "PB_RETURN=AUDIO"
if "%PICK%"=="1" set "PB_ARGS=-Action Status"
if "%PICK%"=="2" set "PB_ARGS=-Action Install"
if "%PICK%"=="3" set "PB_ARGS=-Action Remove"
goto RUN

:RUN
:: Bypass vale solo per questo processo; non modifica policy persistenti o GPO.
"%PS%" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0%PB_SCRIPT%" %PB_ARGS%
set "RC=%errorlevel%"
if not "%RC%"=="0" (
  echo.
  echo [ATTENZIONE] Operazione non completata, codice %RC%. Leggi l'errore sopra.
  echo Se una policy aziendale o la sicurezza blocca l'avvio, fermati e chiedi supporto.
)
echo.
pause
goto %PB_RETURN%

:INPUT_ERROR
echo [ERRORE] Impossibile leggere la scelta. Nessuna nuova operazione avviata.
exit /b 1
