# PrimeBuild-Audio-v4

PRIME BUILD - PrimeBuild-Audio-v4
Windows 11 25H2 e successive

Estrai tutto questo ZIP in una cartella nuova e apri Avvia-PrimeBuild.bat con doppio clic.
Non aprire i PS1: sono componenti interni. Non mescolare versioni o cartelle.

Solo avvio automatico LowAudioLatency: stato, creazione e rimozione.
Scarica e prova prima il tool da https://github.com/spddl/LowAudioLatency.
L'EXE non è incluso: sceglilo nella finestra di selezione e conferma dopo il test.
Opera sul proprio utente, attività Limited, non SYSTEM. Non usare un altro account.
Non avvia subito il tool; verifica al prossimo accesso. Rimuovere l'avvio non chiude il processo.
Nessuna regolazione automatica di EQ, driver o buffer di tutte le app.

I BAT limitano ExecutionPolicy Bypass al processo avviato, senza modifiche permanenti.
Le GPO hanno precedenza; antivirus/SmartScreen non vengono disabilitati.
Verifica la provenienza; se una protezione blocca l avvio, fermati e chiedi supporto.
Questi script non ripristinano i vecchi pack e non promettono guadagni di latenza.
Serve ancora una prova funzionale su PC di test prima della distribuzione stabile.
Supporto: https://discord.gg/ERUwSxE79q
Guide: https://primebuild.website/guides/
